1- Go to the file DisplayJava.java<br>
2- Run the file
